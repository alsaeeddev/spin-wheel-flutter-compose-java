package alsaeeddev.wheelspin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp



class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val context = LocalContext.current
                    val segments = listOf("100", "200", "300", "400", "500", "600", "700", "800")

                    WheelSpinner(
                        segments = segments,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) { result ->
                        Toast.makeText(context, "You won: $result", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}



