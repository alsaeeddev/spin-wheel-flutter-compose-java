package alsaeeddev.wheelspin

import android.graphics.Paint
import android.view.animation.OvershootInterpolator
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random


@Composable
fun WheelSpinner(
    segments: List<String>,
    modifier: Modifier = Modifier,
    onResult: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val angle = remember { Animatable(0f) }
    val radius = 300f
    val sweepAngle = 360f / segments.size
    var selectedIndex by remember { mutableIntStateOf(-1) }


    Column(
        modifier = modifier
            //.fillMaxSize()
            .wrapContentHeight()
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Wheel
        Box(
            modifier = Modifier.size((radius * 1.2).dp)
        ) {

            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val center = Offset(canvasWidth / 2f, canvasHeight / 2f)

                for (i in segments.indices) {
                    val start = i * sweepAngle
                    val hsv = floatArrayOf((i * 360f / segments.size), 0.85f, 0.95f)
                    var color = Color(android.graphics.Color.HSVToColor(hsv))
                    drawArc(
                        color = color,
                        startAngle = angle.value + start,
                        sweepAngle = sweepAngle,
                        useCenter = true,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2, radius * 2)
                    )

                    val median = start + sweepAngle / 2
                    val angleRad = Math.toRadians((angle.value + median).toDouble())
                    val textX = center.x + (radius * 0.6 * cos(angleRad)).toFloat()
                    val textY = center.y + (radius * 0.6 * sin(angleRad)).toFloat()

                    drawContext.canvas.nativeCanvas.apply {
                        drawText(
                            segments[i],
                            textX,
                            textY,
                            Paint().apply {
                                color = Color.White
                                textAlign = Paint.Align.CENTER
                                textSize = 32f
                                isAntiAlias = true
                            }
                        )
                    }
                }

                // Center circle
                drawCircle(Color.White, radius = 35f, center = center)

                // Pointer
                drawPath(
                    path = Path().apply {
                        moveTo(center.x, center.y - radius + 25f)
                        lineTo(center.x - 25f, center.y - radius - 15f)
                        lineTo(center.x + 25f, center.y - radius - 15f)
                        close()
                    },
                    color = Color.Red
                )
            }


        }

        Spacer(modifier = Modifier.height(16.dp)) // spacing below wheel

        // Button
        Button(onClick = {

            coroutineScope.launch {
                val random = Random(System.currentTimeMillis())
                val rounds = random.nextInt(5, 12)
                val extra = random.nextFloat() * 360f
                val totalSpin = rounds * 360 + extra

                angle.animateTo(
                    angle.value + totalSpin,
                    animationSpec = tween(durationMillis = 4000, easing = {
                        OvershootInterpolator(2.5f).getInterpolation(it)
                    })
                )

                val finalNormalized = (angle.value % 360 + 360) % 360
                val fixed = (360 - (finalNormalized - 270) + 360) % 360
                selectedIndex = ((fixed) / sweepAngle).toInt() % segments.size

                onResult(segments[selectedIndex])
            }
        }) {
            Text("Spin")
        }
    }
}

