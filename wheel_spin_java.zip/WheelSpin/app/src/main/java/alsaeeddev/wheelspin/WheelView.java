package alsaeeddev.wheelspin;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.Random;


public class WheelView extends View {

    private String[] segments = new String[0];
    private Paint segmentPaint, textPaint;
    private Paint centerPaint;
    private Paint pointerPaint;
    private Path pointerPath;
    private RectF wheelBounds;
    private float startAngle = 0;
    private float sweepAngle;
    private int selectedIndex = -1;
    private Runnable onSpinEnd;

    private final float[] hsv = new float[3];

    public WheelView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        segmentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(40f);
        textPaint.setTextAlign(Paint.Align.CENTER);

        //  Initialize reusable paints and path
        centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        centerPaint.setColor(Color.WHITE);

        pointerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pointerPaint.setColor(Color.RED);

        pointerPath = new Path();
    }

    public void setSegments(String[] segments) {
        this.segments = segments;
        sweepAngle = 360f / segments.length;
        invalidate();
    }

    public void spinWheel(Runnable onSpinEnd) {
        this.onSpinEnd = onSpinEnd;

        Random random = new Random();
        int rounds = random.nextInt(8) + 5; // 5–12 rounds
        float extra = random.nextFloat() * 360f;
        float finalAngle = rounds * 360f + extra;

        ValueAnimator animator = ValueAnimator.ofFloat(startAngle, startAngle + finalAngle);
        animator.setDuration(4000); // smooth and dramatic
        animator.setInterpolator(new android.view.animation.DecelerateInterpolator(2.5f));
        animator.addUpdateListener(animation -> {
            startAngle = (float) animation.getAnimatedValue();
            invalidate();
        });

        animator.addListener(new Animator.AnimatorListener() {
            public void onAnimationStart(@NonNull Animator animation) {}
            public void onAnimationCancel(@NonNull Animator animation) {}
            public void onAnimationRepeat(@NonNull Animator animation) {}

            public void onAnimationEnd(@NonNull Animator animation) {
                float normalized = (startAngle % 360 + 360) % 360;
                float fixedAngle = (360 - (normalized - 270) + 360) % 360;
                selectedIndex = (int) (fixedAngle / sweepAngle) % segments.length;
                if (onSpinEnd != null) onSpinEnd.run();
            }
        });

        animator.start();
    }

    public String getCurrentSegment() {
        if (selectedIndex >= 0 && selectedIndex < segments.length) {
            return segments[selectedIndex];
        }
        return "";
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);

        if (segments == null || segments.length == 0) return;

        float centerX = getWidth() / 2f;
        float centerY = getHeight() / 2f;
        float radius = Math.min(centerX, centerY) - 10;

        if (wheelBounds == null) {
            wheelBounds = new RectF(centerX - radius, centerY - radius, centerX + radius, centerY + radius);
        }

        float angle = startAngle;
        for (int i = 0; i < segments.length; i++) {
            hsv[0] = (i * 360f / segments.length); // Hue
            hsv[1] = 0.85f;                        // Saturation
            hsv[2] = 0.95f;                        // Value
            segmentPaint.setColor(Color.HSVToColor(hsv));

            canvas.drawArc(wheelBounds, angle, sweepAngle, true, segmentPaint);

            // Draw segment text
            float medianAngle = angle + sweepAngle / 2;
            float textAngle = (float) Math.toRadians(medianAngle);
            float textRadius = radius * 0.65f;

            float x = (float) (centerX + textRadius * Math.cos(textAngle));
            float y = (float) (centerY + textRadius * Math.sin(textAngle));

            canvas.save();
            canvas.rotate(medianAngle, x, y);
            canvas.drawText(segments[i], x, y, textPaint);
            canvas.restore();

            angle += sweepAngle;
        }

        //Use preallocated centerPaint
        canvas.drawCircle(centerX, centerY, 35, centerPaint);
        // Use preallocated pointerPath and pointerPaint
        pointerPath.reset();
        pointerPath.moveTo(centerX, centerY - radius + 25);       // Tip (pointing to wheel)
        pointerPath.lineTo(centerX - 25, centerY - radius - 15);   // Left base
        pointerPath.lineTo(centerX + 25, centerY - radius - 15);   // Right base
        pointerPath.close();
        canvas.drawPath(pointerPath, pointerPaint);
    }
}
