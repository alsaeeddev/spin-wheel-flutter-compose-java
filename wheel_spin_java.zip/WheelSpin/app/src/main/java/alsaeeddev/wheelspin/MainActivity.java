package alsaeeddev.wheelspin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    WheelView wheelView;
    Button btnSpin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        wheelView = findViewById(R.id.wheelView);
        btnSpin = findViewById(R.id.btnSpin);

        wheelView.setSegments(new String[]{"100", "200", "300", "400", "500", "600", "700", "800"});

        btnSpin.setOnClickListener(v -> {
            wheelView.spinWheel(() -> {
                String result = wheelView.getCurrentSegment();
                Toast.makeText(this, "You won: " + result, Toast.LENGTH_SHORT).show();
            });
        });
    }





}
