import 'dart:math';
import 'package:flutter/material.dart';

class SpinWheel extends StatefulWidget {
  final List<String> segments;
  final void Function(String result) onSpinEnd;

  const SpinWheel({
    Key? key,
    required this.segments,
    required this.onSpinEnd,
  }) : super(key: key);

  @override
  SpinWheelState createState() => SpinWheelState();
}

class SpinWheelState extends State<SpinWheel> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double _startAngle = 0.0;
  int _selectedIndex = -1;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 4));
    _animation = Tween<double>(begin: 0, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.decelerate),
    )..addListener(() {
      setState(() {
        _startAngle = _animation.value;
      });
    })..addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        double normalized = (_startAngle % 360 + 360) % 360;
        double fixedAngle = (360 - (normalized - 270) + 360) % 360;
        double sweepAngle = 360 / widget.segments.length;
        _selectedIndex = (fixedAngle ~/ sweepAngle) % widget.segments.length;

        widget.onSpinEnd(widget.segments[_selectedIndex]);
      }
    });
  }

  void spin() {
    final random = Random();
    final rounds = random.nextInt(8) + 5;
    final extra = random.nextDouble() * 360;
    final finalAngle = _startAngle + rounds * 360 + extra;

    _animation = Tween<double>(begin: _startAngle, end: finalAngle).animate(
      CurvedAnimation(parent: _controller, curve: Curves.decelerate),
    );

    _controller.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        CustomPaint(
          painter: WheelPainter(
            segments: widget.segments,
            startAngle: _startAngle,
          ),
          child: const SizedBox(width: 300, height: 300),
        ),
        Positioned(
          top: 0,
          child: CustomPaint(
            painter: PointerPainter(),
            child: const SizedBox(width: 20, height: 20),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}

class WheelPainter extends CustomPainter {
  final List<String> segments;
  final double startAngle;

  WheelPainter({required this.segments, required this.startAngle});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = min(size.width, size.height) / 2 - 10;
    final sweep = 2 * pi / segments.length;
    final textPainter = TextPainter(textAlign: TextAlign.center, textDirection: TextDirection.ltr);

    final segmentPaint = Paint()..style = PaintingStyle.fill;
    final textStyle = const TextStyle(color: Colors.white, fontSize: 16);

    for (int i = 0; i < segments.length; i++) {
      final hue = (i * 360.0 / segments.length);
      final color = HSVColor.fromAHSV(1, hue, 0.85, 0.95).toColor();
      segmentPaint.color = color;

      final segmentStart = radians(startAngle) + i * sweep;

      final rect = Rect.fromCircle(center: center, radius: radius);
      canvas.drawArc(rect, segmentStart, sweep, true, segmentPaint);

      // Draw segment text
      final medianAngle = segmentStart + sweep / 2;
      final textX = center.dx + radius * 0.65 * cos(medianAngle);
      final textY = center.dy + radius * 0.65 * sin(medianAngle);

      canvas.save();
      canvas.translate(textX, textY);
      canvas.rotate(medianAngle);
      textPainter.text = TextSpan(text: segments[i], style: textStyle);
      textPainter.layout();
      textPainter.paint(canvas, Offset(-textPainter.width / 2, -textPainter.height / 2));
      canvas.restore();
    }

    // Draw center white circle
    final centerPaint = Paint()..color = Colors.white;
    canvas.drawCircle(center, 20, centerPaint);
  }

  double radians(double deg) => deg * pi / 180;

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}



class PointerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.red..style = PaintingStyle.fill;

    final path = Path();
    // Arrow pointing downward
    path.moveTo(size.width / 2, size.height);        // Tip
    path.lineTo(size.width / 2 - 10, size.height - 20); // Left
    path.lineTo(size.width / 2 + 10, size.height - 20); // Right
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

