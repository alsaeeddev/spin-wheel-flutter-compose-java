import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'spin_wheel.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: SpinWheelPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SpinWheelPage extends StatefulWidget {
  const SpinWheelPage({super.key});

  @override
  State<SpinWheelPage> createState() => _SpinWheelPageState();
}

class _SpinWheelPageState extends State<SpinWheelPage> {
  final GlobalKey<SpinWheelState> _wheelKey = GlobalKey();

  final List<String> segments = [
    "100", "200", "300", "400", "500", "600", "700", "800"
  ];

/*  void _onSpinEnd(String result) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('You won: $result')),
    );
  }*/

  void _onSpinEnd(String result) {
    Fluttertoast.showToast(
      msg: "You won: $result 🎉",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Spin the Wheel')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SpinWheel(
              key: _wheelKey,
              segments: segments,
              onSpinEnd: _onSpinEnd,
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                _wheelKey.currentState?.spin();
              },
              child: const Text("SPIN"),
            ),
          ],
        ),
      ),
    );
  }
}
