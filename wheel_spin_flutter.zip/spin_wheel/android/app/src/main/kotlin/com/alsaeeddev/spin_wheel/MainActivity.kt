package com.alsaeeddev.spin_wheel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
